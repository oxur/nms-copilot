"""Serial current-assignment gates through the already inspected raw-first capture API."""
import importlib.util,sys
spec=importlib.util.spec_from_file_location('cap','/private/tmp/nms-slice19-cdc-capture.py')
cap=importlib.util.module_from_spec(spec);spec.loader.exec_module(cap)
pre=[
('format',['make','format'],{}),
('lint',['make','lint'],{}),
('focused-libs',['cargo','test','-p','nms-copilot','-p','nms-core','-p','nms-graph','-p','nms-watch','--lib','--all-features'],{}),
('cache',['cargo','test','-p','nms-cache','--all-features'],{}),
('query-route',['cargo','test','-p','nms-copilot','--all-features','--test','query_cache_integration','--test','route_cache_integration'],{}),
('headless',['cargo','test','-p','nms-copilot','--all-features','--test','mcp_live_integration'],{}),
('owned',['cargo','test','-p','nms-copilot','--all-features','--test','owned_mcp_integration'],{}),
('no-default',['cargo','test','-p','nms-copilot','--lib','--no-default-features'],{}),
('binary',['cargo','test','-p','nms-copilot','--bin','nms-copilot','--all-features'],{}),
('native-build',['cargo','build','-p','nms-copilot','--all-features','--bin','nms-copilot','--example','repl_live_probe'],{}),
('self-check',['cargo','run','-p','nms-copilot','--example','repl_live_probe','--','self-check'],{}),
]
post=[
('workspace',['make','test'],{}),
('workspace-build',['cargo','build','--workspace','--all-features'],{}),
('workspace-doc',['cargo','test','--workspace','--all-features','--doc'],{}),
('public-doc',['cargo','doc','-p','nms-copilot','-p','nms-cache','-p','nms-core','-p','nms-graph','-p','nms-query','-p','nms-watch','--no-deps','--all-features'],{}),
('strict-cache',['cargo','doc','-p','nms-cache','--no-deps'],{'RUSTDOCFLAGS':'-D rustdoc::broken_intra_doc_links'}),
('strict-watch',['cargo','doc','-p','nms-watch','--no-deps'],{'RUSTDOCFLAGS':'-D rustdoc::broken_intra_doc_links'}),
('working-diff',['git','diff','--check'],{}),
('base-diff',['git','diff','e592ecf061407cf13a40478c4d05bd78e4dd007f','--check'],{}),
]
phase=sys.argv[1]
if phase not in ('pre','post'):raise SystemExit('expected pre or post')
for label,argv,overrides in (pre if phase=='pre' else post):
 status=cap.capture('cdc-current-'+label,argv,overrides)
 if status:raise SystemExit(status)
