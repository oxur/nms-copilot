(async function run(row,mode,watch='enabled',ending='quit\r') {
const root='/Users/oubiwann/lab/oxur/nms-copilot/.worktrees/community-import-contract';
const helper='/private/tmp/nms-slice28-cc-native-v2.py';
const sq=s=>"'"+s.replace(/'/g,"'\\''")+"'";
const args=(cmd,extra={})=>({cmd,workdir:root,yield_time_ms:1000,max_output_tokens:12000,...extra});
const reserved=await tools.exec_command(args('python3 '+sq(helper)+' reserve-prepare',{yield_time_ms:15000}));
store('cc28-native-reserve-prepare-'+row,reserved);
if(reserved.exit_code!==0)throw Error('prepare receipt reservation failed '+JSON.stringify(reserved));
const receiptPath=reserved.output.trim();
if(!receiptPath.startsWith('/private/tmp/nms-slice28-cc-native-v2/outer-prepare/')||!receiptPath.endsWith('.json'))throw Error('reserved prepare receipt escaped its v2 namespace');
await tools.apply_patch('*** Begin Patch\n*** Add File: '+receiptPath+'.reservation.json\n+'+JSON.stringify(reserved)+'\n*** End Patch');
const init=await tools.exec_command(args('python3 '+sq(helper)+' prepare '+row+' '+sq(mode)+' '+sq(watch),{yield_time_ms:15000}));
store('cc28-native-prepare-'+row,init);
await tools.apply_patch('*** Begin Patch\n*** Add File: '+receiptPath+'\n+'+JSON.stringify(init)+'\n*** End Patch');
if(init.exit_code!==0)throw Error('prepare failed '+JSON.stringify(init));
const ctx=JSON.parse(init.output.split('\n').find(x=>x.startsWith('CONTEXT=')).slice(8));
store('cc28NativeCase'+row,ctx);
let n=0;const terminal=[];
async function call(label,tool,a) {
 const request=ctx.dir+'/request-'+(++n)+'.json';
 const spec={label,tool,args:a,case:{id:ctx.id,row,fixture:ctx.fixture}};
 await tools.apply_patch('*** Begin Patch\n*** Add File: '+request+'\n+'+JSON.stringify(spec)+'\n*** End Patch');
 const pre=await tools.exec_command(args('python3 '+sq(helper)+' register '+sq(request),{yield_time_ms:15000}));
 if(pre.exit_code!==0)throw Error('preregister failed '+JSON.stringify(pre));
 const reg=JSON.parse(pre.output);
 let result;
 try { result=await tools[tool](a); }
 catch(error) {
  const receipt={kind:'tool exception; no returned raw result object',name:error.name,message:error.message};
  store('cc28-native-'+reg.id+'-exception',receipt);
  await tools.apply_patch('*** Begin Patch\n*** Add File: '+reg.dir+'/'+reg.id+'-tool-error.json\n+'+JSON.stringify(receipt)+'\n*** End Patch');
  throw error;
 }
 store('cc28-native-'+reg.id,result);
 await tools.apply_patch('*** Begin Patch\n*** Add File: '+reg.raw_path+'\n+'+JSON.stringify(result)+'\n*** End Patch');
 const post=await tools.exec_command(args('python3 '+sq(helper)+' finish '+sq(reg.dir)+' '+sq(reg.id),{yield_time_ms:15000}));
 if(post.exit_code!==0)throw Error('post failed; raw preserved '+reg.id);
 if(label==='sut-launch'||label==='sut-restart-launch'||(tool==='write_stdin'&&label.startsWith('sut-')))terminal.push(result.output||'');
 return result;
}
async function shell(label,cmd,host=false) {
 const extra={yield_time_ms:15000,...(host?{sandbox_permissions:'require_escalated',justification:'Authorized local Slice28 native process observation/control on fixture-owned paths.'}:{})};const r=await call(label,'exec_command',args(cmd,extra));
 if(r.exit_code!==0)throw Error(label+' failed '+JSON.stringify(r));return r;
}
const control=async(cmd,marker)=>shell('control-'+cmd,'python3 '+sq(helper)+' control '+sq(ctx.fixture)+' '+sq(cmd)+' '+sq(marker));
let sut,monitor,holder,row10Proof,namesProof;let failed=true;
try {
 let address='127.0.0.1:0';
 if(row===9) {
  holder=await call('holder-launch','exec_command',args("printf '%s\\n' \"$$\" > "+sq(ctx.fixture+'/holder.pid')+"; exec "+sq(root+'/target/debug/examples/repl_live_probe')+" hold-port 127.0.0.1:0 "+sq(ctx.fixture),{sandbox_permissions:'require_escalated',justification:'Own an ephemeral loopback listener for the authorized negative bind test.'}));
  const ready=await shell('holder-ready','python3 '+sq(helper)+' ready '+sq(ctx.fixture)+' hold-port.ready');address=ready.output.trim().slice('occupied='.length);
 }
 const cli="printf '%s\\n' \"$$\" > "+sq(ctx.fixture+'/repl.pid')+"; exec env HOME="+sq(ctx.home)+" TERM=xterm-256color "+sq(root+'/target/debug/nms-copilot')+" --save "+sq(ctx.save)+" --http "+sq(address)+(['sentinel','bypass-missing'].includes(mode)?' --no-cache':'');
 sut=await call('sut-launch','exec_command',args(cli,{tty:true,sandbox_permissions:'require_escalated',justification:'Run the authorized normal candidate against a fresh private fixture using the existing native PTY.'}));
 if(!(row===9&&sut.exit_code===1)) {
 const owned=await shell('sut-owned-pid',"pid=$(cat "+sq(ctx.fixture+'/repl.pid')+"); ps -p \"$pid\" -o pid=,command=",true);
 if(!owned.output.includes(root+'/target/debug/nms-copilot')||!owned.output.includes(ctx.save))throw Error('SUT PID ownership mismatch');
}
 if(row===12||row===13||row===14) {
  const clean=s=>s.replace(/\x1b\[[0-?]*[ -/]*[@-~]/g,'').replace(/\r\n/g,'\n');
  const input=async value=>{const r=await call('sut-input','write_stdin',{session_id:sut.session_id,chars:value,yield_time_ms:300,max_output_tokens:12000});if(r.exit_code!==undefined)throw Error('premature names SUT exit');return clean(r.output||'');};
  const status=async(planets,restarted=false)=>{
   const galaxy=row===12?'Eissentam (9; Lush)':'Euclid (0; Normal)';
   const systems=row===12?4:3;
   const position=row===12&&!restarted?'Anchor':'player position';
   const expected='Galaxy:      '+galaxy+'\nModel:       '+systems+' systems, '+planets+' planets\nPosition:    '+position+' (Euclid, galaxy 0)\nBiome:       (none)\nWarp range:  (none)\n';
   const observed=await input('status\r');if(!observed.includes(expected))throw Error('names first status body mismatch '+observed);return observed;
  };
  const startMonitor=async(restarted,bound)=>{
   const channel=restarted?'names-restart':'names-monitor';
   const command=restarted?'monitor-names-restart':'monitor-names';
   monitor=await call(channel+'-launch','exec_command',args("printf '%s\\n' \"$$\" > "+sq(ctx.fixture+'/monitor.pid')+'; exec '+sq(root+'/target/debug/examples/repl_live_probe')+' '+command+' '+sq(ctx.fixture)+' '+sq(bound)+' > '+sq(ctx.fixture+'/cc-'+channel+'.stdout')+' 2> '+sq(ctx.fixture+'/cc-'+channel+'.stderr'),{sandbox_permissions:'require_escalated',justification:'Observe approved naming lifecycle and cache boundaries through the existing local fixture probe.'}));
   await shell(channel+'-ready','python3 '+sq(helper)+' ready '+sq(ctx.fixture)+' '+(restarted?'restart.names.ready':'monitor.names.ready'));
  };
  const namesControl=async(cmd,marker)=>shell('names-control-'+cmd,'python3 '+sq(helper)+' control '+sq(ctx.fixture)+' '+sq(cmd)+' '+sq(marker)+' names-monitor');
  const finishNames=async(restarted)=>{
   const channel=restarted?'names-restart':'names-monitor';
   const marker=restarted?'name-restart=pass':row===12?'name-lifecycle=pass':row===14?'name-lifecycle=pass profile=predecessor-source':'name-lifecycle=pass profile=predecessor';
   const enqueued=await shell(channel+'-finish-enqueue','python3 '+sq(helper)+' enqueue '+sq(ctx.fixture)+' finish '+sq(marker)+' '+channel);
   const offset=JSON.parse(enqueued.output).offset;
   let end=await call('sut-exit','write_stdin',{session_id:sut.session_id,chars:'quit\r',yield_time_ms:1000,max_output_tokens:12000});
   for(let i=0;end.exit_code===undefined&&i<5;i++)end=await call('sut-eof','write_stdin',{session_id:sut.session_id,chars:'',yield_time_ms:1000,max_output_tokens:12000});
   if(end.exit_code!==0)throw Error('names natural exit0 missing '+JSON.stringify(end));
   await shell(channel+'-finish-marker','python3 '+sq(helper)+' marker '+sq(ctx.fixture)+' '+offset+' '+sq(marker)+' '+channel);
   const me=monitor.session_id?await call(channel+'-eof','write_stdin',{session_id:monitor.session_id,chars:'',yield_time_ms:1000,max_output_tokens:12000}):monitor;
   if(me.exit_code!==0)throw Error('names monitor exit0 missing '+JSON.stringify(me));
   return JSON.parse((await shell(channel+'-post-files','python3 '+sq(helper)+' post '+sq(ctx.fixture))).output);
  };
  const actualBound=terminal.join('').match(/MCP server listening on http:\/\/(127\.0\.0\.1:\d+)/);if(!actualBound)throw Error('names first actual port missing');
  if(row===12)await input('set position "Anchor"\r');
  await startMonitor(false,actualBound[1]);const startupStatus=await status(row===12?3:3);
  let renamedStatus,findNamed,showRenamed,restoredStatus;
  if(row===12){
   for(const phase of ['overwrite','promote','rename'])await namesControl(phase,'name-phase-'+phase+'=pass');
   renamedStatus=await status(4);
   findNamed=await input('find --named --from Anchor\r');
   for(const literal of ['Renamed Moon','Current Renamed','Lush','Kepler','Absent Moon','Absent Import'])if(!findNamed.includes(literal))throw Error('names terminal find missing '+literal+' '+findNamed);
   if(findNamed.includes('Nine Moon'))throw Error('crossGG9 leaked into Anchor find');
   await input('galaxy 0\r');showRenamed=await input('show system "Current Renamed"\r');
   for(const literal of ['Current Renamed','Renamed Moon','Euclid'])if(!showRenamed.includes(literal))throw Error('names terminal show missing '+literal+' '+showRenamed);
   await input('galaxy 9\r');restoredStatus=await status(4);
   for(const phase of ['clear','omit','null','nonstring','nonobject','nonobject-dm','invalid1','invalid2','invalid3','invalid4','invalid5','recover'])await namesControl(phase,'name-phase-'+phase+'=pass');
   await namesControl('identical','name-identical=pass');await status(4);
   notify('CC native row12 name overwrite/promotion/rename/clear/ignored/invalid/recovery/identical and exact terminal/status passed');
  }
  const firstPost=await finishNames(false);const firstTerminal=clean(terminal.join(''));
  if(!firstTerminal.includes('Goodbye!'))throw Error('names first Goodbye missing');
  if(firstTerminal.includes('Warped:'))throw Error('names metadata-only sequence emitted false warp');
  if(row===12){
   for(const [literal,count] of [['  New system: Current (1 planet)',1],['  New scan: "Current Moon" (Toxic) in Current',1],['Warning: 5 consecutive parse failures',1]])if(firstTerminal.split(literal).length-1!==count)throw Error('names expected terminal count '+literal);
  }else { const warning=row===14?'cache schema revision 3 is incompatible (expected 4)':'cache schema revision 3 is incompatible (expected 4)'; if(!firstTerminal.includes(warning))throw Error('genuine name predecessor rejection warning missing '+warning); }
  await shell('names-prepare-restart','python3 '+sq(helper)+' prepare-restart '+sq(ctx.fixture)+' names');
  const secondStart=terminal.length;
  sut=await call('sut-restart-launch','exec_command',args(cli,{tty:true,sandbox_permissions:'require_escalated',justification:'Verify naming-compatible warm reuse in a second real normal PTY process.'}));
  const owned=await shell('sut-restart-owned-pid',"pid=$(cat "+sq(ctx.fixture+'/repl.pid')+"); ps -p \"$pid\" -o pid=,command=",true);
  if(!owned.output.includes(root+'/target/debug/nms-copilot')||!owned.output.includes(ctx.save))throw Error('names restart PID ownership mismatch');
  const nextBound=terminal.slice(secondStart).join('').match(/MCP server listening on http:\/\/(127\.0\.0\.1:\d+)/);if(!nextBound)throw Error('names restart actual bound address missing');
  await startMonitor(true,nextBound[1]);const restartStatus=await status(row===12?4:3,true);
  const secondPost=await finishNames(true);const secondTerminal=clean(terminal.slice(secondStart).join(''));
  if(!secondTerminal.includes('Goodbye!')||secondTerminal.includes('Warped:')||secondTerminal.includes('New system:')||secondTerminal.includes('New scan:'))throw Error('names warm restart terminal mismatch');
  namesProof={profile:mode,startupStatus,renamedStatus,findNamed,showRenamed,restoredStatus,restartStatus,firstPost,secondPost,firstTerminal,secondTerminal};
  notify('CC native row'+row+' both real process EOF/file/cache/name boundaries passed');
 } else if(row===10) {
  const clean=s=>s.replace(/\x1b\[[0-?]*[ -/]*[@-~]/g,'').replace(/\r\n/g,'\n');
  const input=async value=>{const r=await call('sut-input','write_stdin',{session_id:sut.session_id,chars:value,yield_time_ms:300,max_output_tokens:12000});if(r.exit_code!==undefined)throw Error('premature SUT exit');return clean(r.output||'');};
  const status=async(systems,planets,restarted=false)=>{
   const body='Galaxy:      Eissentam (9; Lush)\nModel:       '+systems+' systems, '+planets+' planets\nPosition:    '+(restarted?'player position (Euclid, galaxy 0)':'Anchor-0 (Euclid, galaxy 0)')+'\nBiome:       '+(restarted?'(none)':'Toxic')+'\nWarp range:  '+(restarted?'(none)':'2500 ly')+'\n';
   const observed=await input('status\r');if(!observed.includes(body))throw Error('row10 first idle status mismatch '+observed);return observed;
  };
  const startMonitor=async(restarted,address)=>{
   const channel=restarted?'restart':'monitor';
   const command=restarted?'verify-restart':'monitor-unknown';
   monitor=await call(channel+'-launch','exec_command',args("printf '%s\\n' \"$$\" > "+sq(ctx.fixture+'/monitor.pid')+'; exec '+sq(root+'/target/debug/examples/repl_live_probe')+' '+command+' '+sq(ctx.fixture)+' '+sq(address)+' > '+sq(ctx.fixture+'/cc-'+channel+'.stdout')+' 2> '+sq(ctx.fixture+'/cc-'+channel+'.stderr'),{sandbox_permissions:'require_escalated',justification:'Observe the approved unknown-system lifecycle through the existing local fixture probe.'}));
   await shell(channel+'-ready','python3 '+sq(helper)+' ready '+sq(ctx.fixture)+' '+channel+'.ready');
  };
  const finish=async(restarted)=>{
   const channel=restarted?'restart':'monitor';const marker=restarted?'unknown-restart=pass':'unknown-first-eof=pass';
   const enqueued=await shell(channel+'-finish-enqueue','python3 '+sq(helper)+' enqueue '+sq(ctx.fixture)+' finish '+sq(marker)+' '+channel);
   const offset=JSON.parse(enqueued.output).offset;
   let end=await call('sut-exit','write_stdin',{session_id:sut.session_id,chars:'quit\r',yield_time_ms:1000,max_output_tokens:12000});
   for(let i=0;end.exit_code===undefined&&i<5;i++)end=await call('sut-eof','write_stdin',{session_id:sut.session_id,chars:'',yield_time_ms:1000,max_output_tokens:12000});
   if(end.exit_code!==0)throw Error('row10 natural product exit missing '+JSON.stringify(end));
   await shell(channel+'-finish-marker','python3 '+sq(helper)+' marker '+sq(ctx.fixture)+' '+offset+' '+sq(marker)+' '+channel);
   const me=monitor.session_id?await call(channel+'-eof','write_stdin',{session_id:monitor.session_id,chars:'',yield_time_ms:1000,max_output_tokens:12000}):monitor;
   if(me.exit_code!==0)throw Error('row10 monitor exit0 missing '+JSON.stringify(me));
   const post=await shell(channel+'-post-files','python3 '+sq(helper)+' post '+sq(ctx.fixture));
   return JSON.parse(post.output);
  };
  const bound=terminal.join('').match(/MCP server listening on http:\/\/(127\.0\.0\.1:\d+)/);if(!bound)throw Error('row10 first actual port missing');address=bound[1];
  for(const line of ['set position "Anchor-0"\r','set biome Toxic\r','set warp-range 2500\r'])await input(line);
  await startMonitor(false,address);
  const startupStatus=await status(4,2);
  await control('move','unknown-move=pass');const movedStatus=await status(5,2);
  await control('malformed','unknown-malformed=pass');
  await control('invalid-address','unknown-invalid-address=pass');const invalidStatus=await status(5,2);
  await control('promote','unknown-promotion=pass');const promotedStatus=await status(5,3);
  await control('identical','unknown-identical=pass');
  notify('CC native row10 first process startup/move/malformed/promotion/identical and exact first statuses passed');
  const firstPost=await finish(false);const firstTerminal=clean(terminal.join(''));
  if(!firstTerminal.includes('Goodbye!'))throw Error('row10 first Goodbye missing');
  if(firstTerminal.split('  Warped: unknown -> unknown').length-1!==1)throw Error('row10 movement count is not exactly one');
  if(/Warped:.*(?:Decoy-0|Imported-9)/.test(firstTerminal))throw Error('row10 false spatial identity movement');
  await shell('prepare-restart','python3 '+sq(helper)+' prepare-restart '+sq(ctx.fixture));
  const secondStart=terminal.length;
  sut=await call('sut-restart-launch','exec_command',args(cli,{tty:true,sandbox_permissions:'require_escalated',justification:'Verify the approved compatible warm restart in a second real normal native PTY process.'}));
  const owned=await shell('sut-restart-owned-pid',"pid=$(cat "+sq(ctx.fixture+'/repl.pid')+"); ps -p \"$pid\" -o pid=,command=",true);
  if(!owned.output.includes(root+'/target/debug/nms-copilot')||!owned.output.includes(ctx.save))throw Error('row10 restart PID ownership mismatch');
  const nextBound=terminal.slice(secondStart).join('').match(/MCP server listening on http:\/\/(127\.0\.0\.1:\d+)/);if(!nextBound)throw Error('row10 restart actual port missing');
  await startMonitor(true,nextBound[1]);const restartStatus=await status(5,3,true);
  const secondPost=await finish(true);const secondTerminal=clean(terminal.slice(secondStart).join(''));
  if(!secondTerminal.includes('Goodbye!'))throw Error('row10 restart Goodbye missing');
  if(secondTerminal.includes('Warped:'))throw Error('row10 disabled restart emitted movement');
  row10Proof={startupStatus,movedStatus,invalidStatus,promotedStatus,restartStatus,firstPost,secondPost,firstTerminal,secondTerminal};
  notify('CC native row10 second compatible restart and both process EOF/SSE/cache boundaries passed');
 } else if(row===9) {
  if(sut.session_id)sut=await call('sut-bind-eof','write_stdin',{session_id:sut.session_id,chars:'',yield_time_ms:1000,max_output_tokens:12000});
  if(sut.exit_code!==1)throw Error('expected bind exit1');
  if(!terminal.join('').includes('Address already in use'))throw Error('missing concrete bind error');
  if(terminal.join('').includes('🚀')||terminal.join('').includes('MCP server listening on'))throw Error('unexpected normal readiness/prompt');
  await shell('post-bind-verifier',sq(root+'/target/debug/examples/repl_live_probe')+' verify-bind-failure '+sq(ctx.fixture));
  await shell('holder-release',"printf '%s\\n' release >> "+sq(ctx.fixture+'/monitor.commands'));
  const h=holder.session_id?await call('holder-eof','write_stdin',{session_id:holder.session_id,chars:'',yield_time_ms:1000,max_output_tokens:12000}):holder;
  if(h.exit_code!==0)throw Error('holder did not exit0');
 } else {
  const found=terminal.join('').match(/MCP server listening on http:\/\/(127\.0\.0\.1:\d+)/);if(!found)throw Error('actual bound address missing');address=found[1];
  monitor=await call('monitor-launch','exec_command',args("printf '%s\\n' \"$$\" > "+sq(ctx.fixture+'/monitor.pid')+"; exec "+sq(root+'/target/debug/examples/repl_live_probe')+" monitor "+sq(ctx.fixture)+' '+sq(address)+' > '+sq(ctx.fixture+'/cc-monitor.stdout')+' 2> '+sq(ctx.fixture+'/cc-monitor.stderr'),{sandbox_permissions:'require_escalated',justification:'Observe real local HTTP/SSE/cache state through the approved existing fixture probe.'}));
  await shell('monitor-ready','python3 '+sq(helper)+' ready '+sq(ctx.fixture)+' monitor.ready');
  const input=async text=>{const r=await call('sut-input','write_stdin',{session_id:sut.session_id,chars:text,yield_time_ms:300,max_output_tokens:12000});if(r.exit_code!==undefined)throw Error('premature SUT exit');return r;};
  const clean=s=>s.replace(/\x1b\[[0-?]*[ -/]*[@-~]/g,'').replace(/\r\n/g,'\n');
  if(row===1) {
   await control('quiet 650','quiet-window=pass ms=650');
   for(const line of ['set position "Base-0"\r','set biome Toxic\r','set warp-range 2500\r'])await input(line);
   for(let phase=1;phase<=4;phase++)await control('phase '+phase,'phase-'+phase+'=pass');
   const s4=clean((await input('status\r')).output||'');
   const body9='Galaxy:      Eissentam (9; Lush)\nModel:       2 systems, 2 planets\nPosition:    Base-0 (Euclid, galaxy 0)\nBiome:       Toxic\nWarp range:  2500 ly\n';
   if(!s4.includes(body9))throw Error('phase4 first status body mismatch '+s4);
   notify('CC native row1 phase4 exact status passed');
   await control('phase 5','phase-5=pass');
   for(let bad=0;bad<5;bad++)await control('malformed','malformed=pass');
   await control('phase 6','phase-6=pass');
   await control('identical','identical-rewrite=pass');
   const s6=clean((await input('status\r')).output||'');
   if(!s6.includes(body9.replace('Eissentam (9; Lush)','Euclid (0; Normal)')))throw Error('return first status body mismatch '+s6);
  } else if(row===11) {
   await control('quiet 650','quiet-window=pass ms=650');
   const observed=clean((await input('status\r')).output||'');
   const expected='Galaxy:      Euclid (0; Normal)\nModel:       1 systems, 0 planets\nPosition:    player position (Euclid, galaxy 0)\nBiome:       (none)\nWarp range:  (none)\n';
   if(!observed.includes(expected))throw Error('predecessor first status mismatch '+observed);
  } else if(row===7)await control('disabled-cross','disabled-cross=pass');
  else await control('single-cross','single-cross=pass');
  await control('pre-exit','pre-exit-boundary=pass');
  let end=await call('sut-exit','write_stdin',{session_id:sut.session_id,chars:ending,yield_time_ms:1000,max_output_tokens:12000});
  for(let i=0;end.exit_code===undefined&&i<5;i++)end=await call('sut-eof','write_stdin',{session_id:sut.session_id,chars:'',yield_time_ms:1000,max_output_tokens:12000});
  if(end.exit_code!==0||!terminal.join('').includes('Goodbye!'))throw Error('natural exit/Goodbye missing');
  await control('close','remote-sse-close=pass');
  const me=monitor.session_id?await call('monitor-eof','write_stdin',{session_id:monitor.session_id,chars:'',yield_time_ms:1000,max_output_tokens:12000}):monitor;
  if(me.exit_code!==0)throw Error('monitor did not exit0 '+JSON.stringify(me));
  const all=clean(terminal.join(''));
  if(row===1) {
   for(const [note,count] of [['  Warped: Origin-0 -> Imported-9',1],['  Warped: Imported-9 -> Origin-0',1],['Warning: 5 consecutive parse failures',1]])if(all.split(note).length-1!==count)throw Error('terminal occurrence mismatch '+note);
  }
  if(row===11&&!all.includes('cache schema revision 3 is incompatible (expected 4)'))throw Error('predecessor mismatch warning missing');
  if((row===7||row===11)&&all.includes('Warped:'))throw Error('disabled movement note');
  if(row===8&&(!all.includes('could not write cache')||!all.includes('could not update cache')))throw Error('distinct startup/live cache warnings missing');
 }
 const post=await shell('whole-post-metadata','python3 '+sq(helper)+' post '+sq(ctx.fixture));
 await tools.apply_patch('*** Begin Patch\n*** Add File: '+ctx.dir+'/result.json\n+'+JSON.stringify({row,mode,fixture:ctx.fixture,case_id:ctx.id,result:'pass',source:ctx.ready_context.source,binaries:ctx.ready_context.binaries,terminal_multiplexed:terminal.join(''),post:JSON.parse(post.output),row10Proof,namesProof})+'\n*** End Patch');
 failed=false;text({row,mode,result:'pass',id:ctx.id,fixture:ctx.fixture});
} finally {
 if(failed) {
  store('cc28-native-failed-case',ctx);
  if(sut&&sut.session_id)try { await call('sut-failure-natural-quit','write_stdin',{session_id:sut.session_id,chars:'quit\r',yield_time_ms:1000,max_output_tokens:12000}); } catch(e) { text('Natural failure cleanup receipt error: '+String(e)); }
  const cleanup="import pathlib,subprocess,os,signal,time; f=pathlib.Path("+JSON.stringify(ctx.fixture)+");\nfor name in ['repl.pid','monitor.pid','holder.pid']:\n p=f/name\n if not p.exists(): continue\n pid=int(p.read_text().strip()); observed=subprocess.run(['ps','-p',str(pid),'-o','command='],capture_output=True,text=True).stdout\n if str(f) not in observed: print(name,pid,'not alive/owned; no signal'); continue\n print(name,pid,'verified',observed.strip());os.kill(pid,signal.SIGTERM)\n for _ in range(20):\n  if not subprocess.run(['ps','-p',str(pid)],capture_output=True).returncode==0: break\n  time.sleep(.1)\n else:\n  observed=subprocess.run(['ps','-p',str(pid),'-o','command='],capture_output=True,text=True).stdout\n  if str(f) in observed: os.kill(pid,signal.SIGKILL);print('forced KILL',pid)\n";
  try { await shell('owned-failure-cleanup','python3 -c '+sq(cleanup),true); } catch(e) { text('Owned failure cleanup error '+String(e)); }
  for(const [label,proc] of [['sut',sut],['monitor',monitor],['holder',holder]])if(proc&&proc.session_id)try { await call(label+'-failure-eof','write_stdin',{session_id:proc.session_id,chars:'',yield_time_ms:1000,max_output_tokens:12000}); }catch(e){text(label+' cleanup completion: '+String(e));}
  text({row,result:'failed; context/receipts preserved; cleanup cannot pass case',id:ctx.id,fixture:ctx.fixture});
 }
}
})
