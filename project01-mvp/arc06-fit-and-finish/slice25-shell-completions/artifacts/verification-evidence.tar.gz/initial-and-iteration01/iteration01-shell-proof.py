#!/usr/bin/env python3
"""Bounded real-child syntax, registration, and Bash candidate proof."""

import base64
import json
import os
import shlex
import subprocess
import sys
import tempfile
from pathlib import Path


SOURCE = Path("/Users/oubiwann/lab/oxur/nms-copilot/.worktrees/shell-completions")
BINARY = SOURCE / "target/debug/nms"
BASH = Path("/opt/homebrew/bin/bash")
ZSH = Path("/bin/zsh")
TIMEOUT_SECONDS = 10


def require(condition: bool, message: str) -> None:
    if not condition:
        raise AssertionError(message)


def channel(value: bytes | str | None) -> dict[str, str | int] | None:
    if value is None:
        return None
    raw = value.encode("utf-8") if isinstance(value, str) else value
    return {"base64": base64.b64encode(raw).decode("ascii"), "bytes": len(raw)}


def emit_receipt(receipt: dict[str, object]) -> None:
    print(json.dumps(receipt, sort_keys=True), flush=True)


def run(stage: str, argv: list[str], env: dict[str, str]) -> subprocess.CompletedProcess[bytes]:
    try:
        result = subprocess.run(
            argv,
            cwd=SOURCE,
            env=env,
            capture_output=True,
            timeout=TIMEOUT_SECONDS,
            check=False,
        )
    except subprocess.TimeoutExpired as error:
        emit_receipt(
            {
                "stage": stage,
                "argv": argv,
                "exception": {"type": type(error).__name__, "message": str(error)},
                "stdout": channel(error.stdout),
                "stderr": channel(error.stderr),
            }
        )
        raise
    emit_receipt(
        {
            "stage": stage,
            "argv": argv,
            "returncode": result.returncode,
            "stdout": channel(result.stdout),
            "stderr": channel(result.stderr),
        }
    )
    require(result.returncode == 0, f"{stage} exited {result.returncode}: {result.stderr!r}")
    require(not result.stderr, f"{stage} wrote stderr: {result.stderr!r}")
    return result


def generate(shell: str, destination: Path, env: dict[str, str]) -> Path:
    result = run(f"generate-{shell}", [str(BINARY), "completions", shell], env)
    script = result.stdout.decode("utf-8")
    require(bool(script), f"generate-{shell} returned empty stdout")
    require("\x1b" not in script, f"generate-{shell} returned ANSI escapes")
    require("NMS Copilot CLI" not in script, f"generate-{shell} returned a CLI banner")
    require("SAVE FILE SUMMARY" not in script, f"generate-{shell} attempted save loading")
    destination.write_text(script, encoding="utf-8")
    return destination


def assert_lines(stage: str, result: subprocess.CompletedProcess[bytes], expected: list[str]) -> None:
    actual = result.stdout.decode("utf-8").splitlines()
    require(actual == expected, f"{stage} stdout mismatch: expected {expected!r}, got {actual!r}")


def main() -> None:
    require(BINARY.is_file(), f"expected built CLI at {BINARY}")
    require(BASH.is_file(), f"authorized Bash executable is unavailable: {BASH}")
    require(ZSH.is_file(), f"authorized Zsh executable is unavailable: {ZSH}")

    with tempfile.TemporaryDirectory(prefix="nms shell completion proof ") as temporary:
        root = Path(temporary)
        home = root / "isolated home"
        home.mkdir()
        script_dir = root / "generated scripts with spaces"
        script_dir.mkdir()
        function_dir = root / "zsh function directory with spaces"
        function_dir.mkdir()

        env = os.environ.copy()
        env.update(
            {
                "HOME": str(home),
                "XDG_CONFIG_HOME": str(home / ".config"),
                "XDG_DATA_HOME": str(home / ".local/share"),
                "XDG_CACHE_HOME": str(home / ".cache"),
            }
        )
        for selector in ("BASH_ENV", "ENV", "ZDOTDIR"):
            env.pop(selector, None)

        bash_script = generate("bash", script_dir / "nms bash completion", env)
        zsh_script = generate("zsh", script_dir / "_nms zsh completion", env)
        generate("fish", script_dir / "nms fish completion", env)

        run("bash-syntax", [str(BASH), "--noprofile", "--norc", "-n", str(bash_script)], env)
        registration = run(
            "bash-registration",
            [
                str(BASH),
                "--noprofile",
                "--norc",
                "-c",
                'source "$1"; complete -p nms',
                "bash",
                str(bash_script),
            ],
            env,
        )
        registration_lines = registration.stdout.decode("utf-8").splitlines()
        require(len(registration_lines) == 1, f"bash-registration lines: {registration_lines!r}")
        registration_tokens = shlex.split(registration_lines[0])
        callbacks = [
            registration_tokens[index + 1]
            for index, token in enumerate(registration_tokens[:-1])
            if token == "-F"
        ]
        require(
            bool(registration_tokens)
            and registration_tokens[0] == "complete"
            and registration_tokens[-1] == "nms"
            and callbacks == ["_nms"],
            f"bash-registration tokens mismatch: {registration_tokens!r}",
        )

        candidate_source = (
            'source "$1"; shift; COMP_WORDS=( "$@" ); '
            'COMP_CWORD=$((${#COMP_WORDS[@]} - 1)); '
            'current="${COMP_WORDS[COMP_CWORD]}"; '
            'previous="${COMP_WORDS[COMP_CWORD-1]}"; '
            '_nms nms "$current" "$previous"; '
            'for candidate in "${COMPREPLY[@]}"; do printf \'%s\\n\' "$candidate"; done'
        )
        bash_cases = [
            (["nms", "ex"], ["export"]),
            (["nms", "--s"], ["--slot"]),
            (["nms", "export", "--na"], ["--named"]),
            (["nms", "export", "--nea"], ["--nearest"]),
            (["nms", "find", "--bi"], ["--biome"]),
            (["nms", "show", "sy"], ["system"]),
            (["nms", "does-not-exist"], []),
        ]
        for index, (words, expected) in enumerate(bash_cases, start=1):
            result = run(
                f"bash-candidate-{index}",
                [
                    str(BASH),
                    "--noprofile",
                    "--norc",
                    "-c",
                    candidate_source,
                    "bash",
                    str(bash_script),
                    *words,
                ],
                env,
            )
            assert_lines(f"bash-candidate-{index}", result, expected)

        run("zsh-syntax", [str(ZSH), "-f", "-n", str(zsh_script)], env)
        zsh_script.rename(function_dir / "_nms")
        registration = run(
            "zsh-registration",
            [
                str(ZSH),
                "-f",
                "-c",
                'fpath=("$1" $fpath); autoload -Uz compinit; compinit -D; '
                'print -r -- "${_comps[nms]}"; whence -w _nms',
                "zsh",
                str(function_dir),
            ],
            env,
        )
        assert_lines("zsh-registration", registration, ["_nms", "_nms: function"])

    print("Bash, Zsh, and Fish generation; Bash candidates; Bash/Zsh syntax and registration passed.")


if __name__ == "__main__":
    try:
        main()
    except BaseException as error:
        print(f"controller failure: {type(error).__name__}: {error}", file=sys.stderr, flush=True)
        raise
