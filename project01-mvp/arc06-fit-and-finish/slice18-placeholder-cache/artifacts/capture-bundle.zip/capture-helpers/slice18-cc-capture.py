import base64, datetime, hashlib, json, os, pathlib, subprocess, sys, uuid

SOURCE = pathlib.Path('/Users/oubiwann/lab/oxur/nms-copilot/.worktrees/placeholder-cache')
RECORD = pathlib.Path(os.environ.get('SLICE18_CAPTURE_RECORD','/private/tmp/slice18-cc-capture-preflight.json'))

def utc():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()

def save(data):
    tmp = RECORD.with_suffix('.json.pending')
    with tmp.open('w') as f:
        json.dump(data, f, sort_keys=True, indent=2)
        f.write('\n'); f.flush(); os.fsync(f.fileno())
    os.replace(tmp, RECORD)

def source_identity():
    head = subprocess.check_output(['git','rev-parse','HEAD'], cwd=SOURCE).decode().strip()
    diff = subprocess.check_output(['git','diff','HEAD','--binary'], cwd=SOURCE)
    status = subprocess.check_output(['git','status','--porcelain=v2','-z'], cwd=SOURCE).decode(errors='surrogateescape')
    untracked = {}
    listing = subprocess.check_output(['git','ls-files','--others','--exclude-standard','-z'], cwd=SOURCE)
    for name in listing.split(b'\0'):
        if name:
            rel = os.fsdecode(name); body = (SOURCE/rel).read_bytes()
            untracked[rel] = {'bytes':len(body),'sha256':hashlib.sha256(body).hexdigest()}
    working_diff_sha256 = hashlib.sha256(diff).hexdigest()
    identity = {'head':head,'working_diff_sha256':working_diff_sha256,'status':status,'untracked':untracked}
    return {'head':head,'working_diff_sha256':working_diff_sha256,'status':status,'untracked':untracked,'working_identity_sha256':hashlib.sha256(json.dumps(identity,sort_keys=True).encode()).hexdigest()}

def capture(label, argv, overrides=None, kind='SUT gate', inject=False):
    overrides = overrides or {}
    data = json.loads(RECORD.read_text()) if RECORD.exists() else {'purpose':'wrapper-only raw-first capture preflight; no SUT','attempts':[]}
    item = {'uuid':uuid.uuid4().hex,'label':label,'kind':kind,'argv':argv,'cwd':str(SOURCE),'started_utc':utc(),'before':source_identity(),'overrides':overrides,'inherited_env':{k:os.environ.get(k) for k in ('TMPDIR','RUSTDOCFLAGS','CARGO_TARGET_DIR','CARGO_NET_OFFLINE','RUSTUP_TOOLCHAIN','TERM','PATH')},'status':'running'}
    data['attempts'].append(item); save(data)
    try:
        p = subprocess.run(item['argv'],cwd=SOURCE,capture_output=True,env=os.environ|overrides)
    except BaseException as e:
        item['launch_exception'] = {'type':type(e).__name__,'message':str(e),'utc':utc()}
        item['status'] = 'launch-failed'; save(data)
        try:
            item['after'] = source_identity()
        except BaseException as metadata_error:
            item['capture_exception'] = {'type':type(metadata_error).__name__,'message':str(metadata_error),'utc':utc()}
        save(data)
        return item
    item['raw_completion'] = {'exit_code':p.returncode,'ended_utc':utc(),'stdout_b64':base64.b64encode(p.stdout).decode(),'stderr_b64':base64.b64encode(p.stderr).decode()}
    item['status'] = 'child-complete'; save(data)
    try:
        if inject: raise RuntimeError('intentional post-metadata fault after durable raw completion')
        item['after'] = source_identity(); item['status'] = 'complete'; save(data)
    except BaseException as e:
        item['post_metadata_exception'] = {'type':type(e).__name__,'message':str(e),'utc':utc()}; save(data)
    return item

if __name__ == '__main__':
    if sys.argv[1:] == ['--preflight']:
        if RECORD.exists():
            raise SystemExit(f'refusing to overwrite existing capture record: {RECORD}')
        results = [capture('exit7-nonempty-both',[sys.executable,'-c','import sys;print("stdout-seven");print("stderr-seven",file=sys.stderr);sys.exit(7)'],kind='wrapper-only preflight'), capture('exit0-nonempty-both',[sys.executable,'-c','import sys;print("stdout-zero");print("stderr-zero",file=sys.stderr)'],kind='wrapper-only preflight'), capture('fault-after-raw',[sys.executable,'-c','import sys;print("stdout-fault");print("stderr-fault",file=sys.stderr);sys.exit(9)'],kind='wrapper-only preflight',inject=True), capture('launcher-exception',['/private/tmp/slice18-intentionally-missing-launcher'],kind='wrapper-only preflight')]
        assert [x['raw_completion']['exit_code'] for x in results[:3]] == [7,0,9]
        assert results[3]['status'] == 'launch-failed' and 'launch_exception' in results[3] and 'raw_completion' not in results[3]
        assert all('ended_utc' in x['raw_completion'] and 'stdout_b64' in x['raw_completion'] and 'stderr_b64' in x['raw_completion'] for x in results[:3])
        assert all(base64.b64decode(x['raw_completion']['stdout_b64']) and base64.b64decode(x['raw_completion']['stderr_b64']) for x in results[:3])
        assert all(base64.b64decode(x['raw_completion']['stdout_b64']) != base64.b64decode(x['raw_completion']['stderr_b64']) for x in results[:3])
        assert results[2]['status'] == 'child-complete' and 'post_metadata_exception' in results[2]
        print(json.dumps({'record':str(RECORD),'attempts':[{'uuid':x['uuid'],'label':x['label'],'exit_code':x.get('raw_completion',{}).get('exit_code'),'status':x['status'],'launch_exception':x.get('launch_exception')} for x in results]}))
    else:
        label = sys.argv[1]
        spec = json.loads(sys.argv[2])
        capture(label, spec['argv'], spec.get('overrides'), spec.get('kind','SUT gate'), spec.get('inject_post_metadata_failure',False))
