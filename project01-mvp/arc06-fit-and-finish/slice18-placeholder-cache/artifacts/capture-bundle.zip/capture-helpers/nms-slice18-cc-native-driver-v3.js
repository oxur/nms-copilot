(async function run(row,mode,watch='enabled',ending='quit\r') {
const root='/Users/oubiwann/lab/oxur/nms-copilot/.worktrees/placeholder-cache';
const helper='/private/tmp/nms-slice18-cc-native.py';
const sq=s=>"'"+s.replace(/'/g,"'\\''")+"'";
const args=(cmd,extra={})=>({cmd,workdir:root,yield_time_ms:1000,max_output_tokens:12000,...extra});
const init=await tools.exec_command(args('python3 '+sq(helper)+' prepare '+row+' '+sq(mode)+' '+sq(watch),{yield_time_ms:15000}));
store('cc-native-prepare-'+row,init);
if(init.exit_code!==0)throw Error('prepare failed '+JSON.stringify(init));
const ctx=JSON.parse(init.output.split('\n').find(x=>x.startsWith('CONTEXT=')).slice(8));
store('ccNativeCase'+row,ctx);
let n=0;const terminal=[];
async function call(label,tool,a) {
 const request=ctx.dir+'/request-'+(++n)+'.json';
 const spec={label,tool,args:a,case:{id:ctx.id,row,fixture:ctx.fixture}};
 await tools.apply_patch('*** Begin Patch\n*** Add File: '+request+'\n+'+JSON.stringify(spec)+'\n*** End Patch');
 const pre=await tools.exec_command(args('python3 '+sq(helper)+' register '+sq(request)));
 if(pre.exit_code!==0)throw Error('preregister failed '+JSON.stringify(pre));
 const reg=JSON.parse(pre.output);
 let result;
 try { result=await tools[tool](a); }
 catch(error) {
  const receipt={kind:'tool exception; no returned raw result object',name:error.name,message:error.message};
  store('cc-native-'+reg.id+'-exception',receipt);
  await tools.apply_patch('*** Begin Patch\n*** Add File: '+reg.dir+'/'+reg.id+'-tool-error.json\n+'+JSON.stringify(receipt)+'\n*** End Patch');
  throw error;
 }
 store('cc-native-'+reg.id,result);
 await tools.apply_patch('*** Begin Patch\n*** Add File: '+reg.raw_path+'\n+'+JSON.stringify(result)+'\n*** End Patch');
 const post=await tools.exec_command(args('python3 '+sq(helper)+' finish '+sq(reg.dir)+' '+sq(reg.id)));
 if(post.exit_code!==0)throw Error('post failed; raw preserved '+reg.id);
 if(label==='sut-launch'||(tool==='write_stdin'&&label.startsWith('sut-')))terminal.push(result.output||'');
 return result;
}
async function shell(label,cmd,host=false) {
 const extra={yield_time_ms:15000,...(host?{sandbox_permissions:'require_escalated',justification:'Authorized local Slice18 native process observation/control on fixture-owned paths.'}:{})};const r=await call(label,'exec_command',args(cmd,extra));
 if(r.exit_code!==0)throw Error(label+' failed '+JSON.stringify(r));return r;
}
const control=async(cmd,marker)=>shell('control-'+cmd,'python3 '+sq(helper)+' control '+sq(ctx.fixture)+' '+sq(cmd)+' '+sq(marker));
let sut,monitor,holder;let failed=true;
try {
 let address='127.0.0.1:0';
 if(row===9) {
  holder=await call('holder-launch','exec_command',args("printf '%s\\n' \"$$\" > "+sq(ctx.fixture+'/holder.pid')+"; exec "+sq(root+'/target/debug/examples/repl_live_probe')+" hold-port 127.0.0.1:0 "+sq(ctx.fixture),{sandbox_permissions:'require_escalated',justification:'Own an ephemeral loopback listener for the authorized negative bind test.'}));
  const ready=await shell('holder-ready','python3 '+sq(helper)+' ready '+sq(ctx.fixture)+' hold-port.ready');address=ready.output.trim().slice('occupied='.length);
 }
 const cli="printf '%s\\n' \"$$\" > "+sq(ctx.fixture+'/repl.pid')+"; exec env HOME="+sq(ctx.home)+" TERM=xterm-256color "+sq(root+'/target/debug/nms-copilot')+" --save "+sq(ctx.save)+" --http "+sq(address)+(['sentinel','bypass-missing'].includes(mode)?' --no-cache':'');
 sut=await call('sut-launch','exec_command',args(cli,{tty:true,sandbox_permissions:'require_escalated',justification:'Run the authorized normal candidate against a fresh private fixture using the existing native PTY.'}));
 if(!(row===9&&sut.exit_code===1)) {
 const owned=await shell('sut-owned-pid',"pid=$(cat "+sq(ctx.fixture+'/repl.pid')+"); ps -p \"$pid\" -o pid=,command=",true);
 if(!owned.output.includes(root+'/target/debug/nms-copilot')||!owned.output.includes(ctx.save))throw Error('SUT PID ownership mismatch');
}
 if(row===9) {
  if(sut.session_id)sut=await call('sut-bind-eof','write_stdin',{session_id:sut.session_id,chars:'',yield_time_ms:1000,max_output_tokens:12000});
  if(sut.exit_code!==1)throw Error('expected bind exit1');
  if(!terminal.join('').includes('Address already in use'))throw Error('missing concrete bind error');
  if(terminal.join('').includes('🚀')||terminal.join('').includes('MCP server listening on'))throw Error('unexpected normal readiness/prompt');
  await shell('post-bind-verifier',sq(root+'/target/debug/examples/repl_live_probe')+' verify-bind-failure '+sq(ctx.fixture));
  await shell('holder-release',"printf '%s\\n' release >> "+sq(ctx.fixture+'/monitor.commands'));
  const h=holder.session_id?await call('holder-eof','write_stdin',{session_id:holder.session_id,chars:'',yield_time_ms:1000,max_output_tokens:12000}):holder;
  if(h.exit_code!==0)throw Error('holder did not exit0');
 } else {
  const found=terminal.join('').match(/MCP server listening on http:\/\/(127\.0\.0\.1:\d+)/);if(!found)throw Error('actual bound address missing');address=found[1];
  monitor=await call('monitor-launch','exec_command',args("printf '%s\\n' \"$$\" > "+sq(ctx.fixture+'/monitor.pid')+"; exec "+sq(root+'/target/debug/examples/repl_live_probe')+" monitor "+sq(ctx.fixture)+' '+sq(address)+' > '+sq(ctx.fixture+'/cc-monitor.stdout')+' 2> '+sq(ctx.fixture+'/cc-monitor.stderr'),{sandbox_permissions:'require_escalated',justification:'Observe real local HTTP/SSE/cache state through the approved existing fixture probe.'}));
  await shell('monitor-ready','python3 '+sq(helper)+' ready '+sq(ctx.fixture)+' monitor.ready');
  const input=async text=>{const r=await call('sut-input','write_stdin',{session_id:sut.session_id,chars:text,yield_time_ms:300,max_output_tokens:12000});if(r.exit_code!==undefined)throw Error('premature SUT exit');return r;};
  const clean=s=>s.replace(/\x1b\[[0-?]*[ -/]*[@-~]/g,'').replace(/\r\n/g,'\n');
  if(row===1) {
   await control('quiet 650','quiet-window=pass ms=650');
   for(const line of ['set position "Base-0"\r','set biome Toxic\r','set warp-range 2500\r'])await input(line);
   for(let phase=1;phase<=4;phase++)await control('phase '+phase,'phase-'+phase+'=pass');
   const s4=clean((await input('status\r')).output||'');
   const body9='Galaxy:      Eissentam (9; Lush)\nModel:       2 systems, 2 planets\nPosition:    Base-0 (Euclid, galaxy 0)\nBiome:       Toxic\nWarp range:  2500 ly\n';
   if(!s4.includes(body9))throw Error('phase4 first status body mismatch '+s4);
   notify('CC native row1 phase4 exact status passed');
   await control('phase 5','phase-5=pass');
   for(let bad=0;bad<5;bad++)await control('malformed','malformed=pass');
   await control('phase 6','phase-6=pass');
   await control('identical','identical-rewrite=pass');
   const s6=clean((await input('status\r')).output||'');
   if(!s6.includes(body9.replace('Eissentam (9; Lush)','Euclid (0; Normal)')))throw Error('return first status body mismatch '+s6);
  } else if(row===7)await control('disabled-cross','disabled-cross=pass');
  else await control('single-cross','single-cross=pass');
  await control('pre-exit','pre-exit-boundary=pass');
  let end=await call('sut-exit','write_stdin',{session_id:sut.session_id,chars:ending,yield_time_ms:1000,max_output_tokens:12000});
  for(let i=0;end.exit_code===undefined&&i<5;i++)end=await call('sut-eof','write_stdin',{session_id:sut.session_id,chars:'',yield_time_ms:1000,max_output_tokens:12000});
  if(end.exit_code!==0||!terminal.join('').includes('Goodbye!'))throw Error('natural exit/Goodbye missing');
  await control('close','remote-sse-close=pass');
  const me=monitor.session_id?await call('monitor-eof','write_stdin',{session_id:monitor.session_id,chars:'',yield_time_ms:1000,max_output_tokens:12000}):monitor;
  if(me.exit_code!==0)throw Error('monitor did not exit0 '+JSON.stringify(me));
  const all=clean(terminal.join(''));
  if(row===1) {
   for(const [note,count] of [['  Warped: Origin-0 -> Imported-9',1],['  Warped: Imported-9 -> Origin-0',1],['Warning: 5 consecutive parse failures',1]])if(all.split(note).length-1!==count)throw Error('terminal occurrence mismatch '+note);
  }
  if(row===7&&all.includes('Warped:'))throw Error('disabled movement note');
  if(row===8&&(!all.includes('could not write cache')||!all.includes('could not update cache')))throw Error('distinct startup/live cache warnings missing');
 }
 const post=await shell('whole-post-metadata','python3 '+sq(helper)+' post '+sq(ctx.fixture));
 await tools.apply_patch('*** Begin Patch\n*** Add File: '+ctx.dir+'/result.json\n+'+JSON.stringify({row,mode,fixture:ctx.fixture,case_id:ctx.id,result:'pass',source:ctx.ready_context.source,binaries:ctx.ready_context.binaries,terminal_multiplexed:terminal.join(''),post:JSON.parse(post.output)})+'\n*** End Patch');
 failed=false;text({row,mode,result:'pass',id:ctx.id,fixture:ctx.fixture});
} finally {
 if(failed) {
  store('cc-native-failed-case',ctx);
  if(sut&&sut.session_id)try { await call('sut-failure-natural-quit','write_stdin',{session_id:sut.session_id,chars:'quit\r',yield_time_ms:1000,max_output_tokens:12000}); } catch(e) { text('Natural failure cleanup receipt error: '+String(e)); }
  const cleanup="import pathlib,subprocess,os,signal,time; f=pathlib.Path("+JSON.stringify(ctx.fixture)+");\nfor name in ['repl.pid','monitor.pid','holder.pid']:\n p=f/name\n if not p.exists(): continue\n pid=int(p.read_text().strip()); observed=subprocess.run(['ps','-p',str(pid),'-o','command='],capture_output=True,text=True).stdout\n if str(f) not in observed: print(name,pid,'not alive/owned; no signal'); continue\n print(name,pid,'verified',observed.strip());os.kill(pid,signal.SIGTERM)\n for _ in range(20):\n  if not subprocess.run(['ps','-p',str(pid)],capture_output=True).returncode==0: break\n  time.sleep(.1)\n else:\n  observed=subprocess.run(['ps','-p',str(pid),'-o','command='],capture_output=True,text=True).stdout\n  if str(f) in observed: os.kill(pid,signal.SIGKILL);print('forced KILL',pid)\n";
  try { await shell('owned-failure-cleanup','python3 -c '+sq(cleanup),true); } catch(e) { text('Owned failure cleanup error '+String(e)); }
  for(const [label,proc] of [['sut',sut],['monitor',monitor],['holder',holder]])if(proc&&proc.session_id)try { await call(label+'-failure-eof','write_stdin',{session_id:proc.session_id,chars:'',yield_time_ms:1000,max_output_tokens:12000}); }catch(e){text(label+' cleanup completion: '+String(e));}
  text({row,result:'failed; context/receipts preserved; cleanup cannot pass case',id:ctx.id,fixture:ctx.fixture});
 }
}
})
