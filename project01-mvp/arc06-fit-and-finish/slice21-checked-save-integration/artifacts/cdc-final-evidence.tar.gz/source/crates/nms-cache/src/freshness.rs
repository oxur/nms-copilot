//! Cache freshness checking.
//!
//! Compares the modification time of the save file against the cache file
//! to determine if the cache is still valid.

use std::fs;
use std::path::Path;
use std::time::SystemTime;

/// Check if the cache file is fresh relative to the save file.
///
/// Returns `true` if the cache exists and is newer than the save file.
/// Returns `false` if the cache is missing, older than the save, or if
/// timestamps can't be read.
pub fn is_cache_fresh(cache_path: &Path, save_path: &Path) -> bool {
    let cache_mtime = match file_mtime(cache_path) {
        Some(t) => t,
        None => return false,
    };
    let save_mtime = match file_mtime(save_path) {
        Some(t) => t,
        None => return false,
    };
    cache_mtime > save_mtime
}

/// Get the modification time of a file.
fn file_mtime(path: &Path) -> Option<SystemTime> {
    fs::metadata(path).ok()?.modified().ok()
}

/// Result of loading or rebuilding a galaxy model.
pub struct LoadResult {
    /// The loaded galaxy model.
    pub model: nms_graph::GalaxyModel,
    /// Whether the model was loaded from cache.
    pub was_cached: bool,
    /// The save file version (for cache write-through).
    pub save_version: u32,
}

/// Load a model from cache if fresh, otherwise parse the save file.
///
/// Freshness is determined only by file modification times. A fresh cache is
/// still checked for a supported envelope and model semantic revision; if its
/// read, decode, or duplicated player reality consistency check fails, startup
/// warns and rebuilds from the save file. This check requires
/// `player.current_reality == player.current_address.reality_index`; it does not
/// compare the independently selected galaxy or previous/freighter addresses.
/// If a compatible cache lacks the physical player's system key, the returned
/// in-memory model includes it and the cache is repaired on a best-effort
/// basis. A failed repair warns but still returns the ensured model with
/// `was_cached` set to `true`. Cold parsing also ensures the key; cache write
/// failure warns without discarding the parsed model. With `no_cache`, neither
/// cache reads nor writes occur, but the parsed model is still ensured.
///
/// # Errors
///
/// Returns an error when the source save cannot be read or parsed. Cache read,
/// compatibility, and repair-write failures are handled as warnings followed
/// by a source rebuild or an in-memory success, as applicable.
pub fn load_or_rebuild(
    cache_path: &Path,
    save_path: &Path,
    no_cache: bool,
) -> Result<LoadResult, Box<dyn std::error::Error>> {
    // Try cache first (unless --no-cache)
    if !no_cache && is_cache_fresh(cache_path, save_path) {
        match crate::read_cache(cache_path) {
            Ok(data) => {
                let save_version = data.save_version;
                let mut model = crate::rebuild_model(&data);
                let system_count = model.system_count();
                model.ensure_player_system();
                if model.system_count() != system_count {
                    let repaired = crate::extract_cache_data(&model, save_version);
                    if let Err(e) = crate::write_cache(&repaired, cache_path) {
                        eprintln!(
                            "Warning: could not repair cache after ensuring player system ({e})"
                        );
                    }
                }
                return Ok(LoadResult {
                    model,
                    was_cached: true,
                    save_version,
                });
            }
            Err(e) => {
                eprintln!("Warning: cache read failed ({e}), rebuilding from save");
            }
        }
    }

    // Parse save file
    let save = nms_save::parse_validated_save_file(save_path)?;
    let save_version = save.root().version;
    let mut model = nms_graph::GalaxyModel::from_validated_save(&save);
    model.ensure_player_system();

    // Write cache for next time
    if !no_cache {
        let data = crate::extract_cache_data(&model, save_version);
        if let Err(e) = crate::write_cache(&data, cache_path) {
            eprintln!("Warning: could not write cache ({e})");
        }
    }

    Ok(LoadResult {
        model,
        was_cached: false,
        save_version,
    })
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::thread;
    use std::time::Duration;

    #[test]
    fn test_fresh_cache_returns_true() {
        let dir = tempfile::tempdir().unwrap();
        let save_path = dir.path().join("save.json");
        let cache_path = dir.path().join("galaxy.rkyv");

        fs::write(&save_path, "save data").unwrap();
        thread::sleep(Duration::from_millis(50));
        fs::write(&cache_path, "cache data").unwrap();

        assert!(is_cache_fresh(&cache_path, &save_path));
    }

    #[test]
    fn test_stale_cache_returns_false() {
        let dir = tempfile::tempdir().unwrap();
        let save_path = dir.path().join("save.json");
        let cache_path = dir.path().join("galaxy.rkyv");

        fs::write(&cache_path, "cache data").unwrap();
        thread::sleep(Duration::from_millis(50));
        fs::write(&save_path, "updated save").unwrap();

        assert!(!is_cache_fresh(&cache_path, &save_path));
    }

    #[test]
    fn test_missing_cache_returns_false() {
        let dir = tempfile::tempdir().unwrap();
        let save_path = dir.path().join("save.json");
        let cache_path = dir.path().join("galaxy.rkyv");

        fs::write(&save_path, "save data").unwrap();
        assert!(!is_cache_fresh(&cache_path, &save_path));
    }

    #[test]
    fn test_missing_save_returns_false() {
        let dir = tempfile::tempdir().unwrap();
        let save_path = dir.path().join("save.json");
        let cache_path = dir.path().join("galaxy.rkyv");

        fs::write(&cache_path, "cache data").unwrap();
        assert!(!is_cache_fresh(&cache_path, &save_path));
    }
}
