# Slice21 checked-save integration — CC proposed red return

Candidate: commit `8a01b3d7ff9d6f3bc958975d07ba0e0e19bb5985` on `codex/checked-save-integration`, parent `0b37d8b41222b8e4a084c088246f777490575756`. It contains exactly 38 authorized paths and the two required consecutive once-only Co-authored-by trailers. The dedicated source worktree is clean and its index is empty. This is a reviewable candidate, not a successful proof or acceptance.

## Proposed CA dispositions

All rows remain OPEN pending CDC independent review. CC does not accept its own evidence.

| Row | CC proposal | Evidence and limit |
|---|---|---|
| CA-01 | Partially supported | `nms-save` checked-save focused and crate gates passed, including required presence/error/file controls. Remaining full `make test` stopped at an unrelated-to-parser cache unit assertion; no overall green claim. |
| CA-02 | Partially supported | `nms-graph` tests and complete literal models passed. They are synthetic; do not infer nonzero game-backed discovery. |
| CA-03 | Open with a confirmed red | The all-eight CLI target fails one actual legacy-fixture child `find --infested`; CDC directly reproduced `No results found.` against a fresh copy. Other actual CLI child fixtures are migrated; see execution inventory. No sixth-pass edit has been authorized. |
| CA-04 | Partially supported | Isolated cache load integration passed and current predecessor/current cases were exercised. Full `make test` exposes a stale unit header expectation (expected semantic 3, observed 4). |
| CA-05 | Partially supported | Watch and owned/headless lifecycle affected targets passed on authorized-host retries after retained restricted-sandbox failures. Full workspace proof remains red. |
| CA-06 | Proposed supported, pending independent reproduction | The exact all-feature headless target passed 20 tests on host; all 11 current native rows passed, including two-process row10 and predecessor row11. Full native raw/tool/file fixtures are inventoried in `validation.json`. |
| CA-07 | Open with a confirmed docs red | Workspace doctests and build passed; strict public API rustdoc fails on `VP[0]`/`VP[1]` intra-doc links in `nms-graph/src/extract.rs`. |
| CA-08 | Open | The 74 CC capture attempts, retained failure/retry histories, exact commit/trailers and bounded direct CDC find reproduction are indexed. CDC owns independent acceptance and any plan/ledger update. |

## Gate outcome

The original focused sequence was captured. Sandbox-restricted watcher/loopback failures were preserved and exact same-command/source/original-TMPDIR retries passed on the authorized host. `make test` exited 2 at the first `nms-cache` unit group (18 passed, one stale semantic-header expectation failed); it did not run later workspace groups. Workspace build, workspace doctests, and both diff checks passed. Strict changed-public-API docs failed on broken intra-doc links. CLI test and its CDC fresh-fixture reproduction remain red. No source repairs were made after the final authorized refinement; the five ordinary passes are exhausted.

See `execution.md` for source-grounded attribution, exact attempt IDs, red output, retry distinctions and inventory corrections. See `validation.json` for all 74 CC attempt summaries and 621 per-file native-artifact hashes; the complete raw CC capture remains at `/private/tmp/nms-slice21-cc-attempts.json`. CDC's direct find reproduction `8edbcd53b93f43e8869f883829b91fd2` is separately identified and is not misattributed to the CC record.

The source, index, returns and gates are frozen for CDC review. No historical exception transfers to another row, and no pass, waiver, acceptance, integration, release, or slice closure is inferred here.

## Approved exceptional refinement06 — current CC proposal

The Operator explicitly approved one consolidated sixth pass. CC changed only the real-child fixture in `find_integration.rs`, the independent semantic-header literal in the existing cache test, and three rustdoc code spans in `extract.rs`. The shared legacy fixture, six other find tests, production code, all other source paths, and existing native controls remain unchanged. The child fixture's five literal JSON-pointer conversions are checked both before and after projection; restoring those five fields on a clone reproduces the full VP-modified input value.

Captured checks on the reviewed candidate all passed: focused find integration7/7; full CLI nine harnesses/155 runtime cases; full cache19 unit +28 integration +2 doctests; direct-host `make test`40 harnesses/1036 runtime +27 doctest cases; strict four-crate rustdoc with `-D warnings`; working and base `git diff --check`. Exact IDs and complete raw channels are recorded in `/private/tmp/nms-slice21-cc-attempts.json`; validation inventory now indexes83 actual attempts and retains the prior74 values. No restricted failure/retry occurred for this sequence. The candidate pin before commit was `8a01b3d7ff9d6f3bc958975d07ba0e0e19bb5985`, tracked diff SHA256 `9b85c2e8d0280d6260191f648c8a7d3baf5724a27857157817812e89faa33856`; no production bytes changed.

This supersedes the preceding red disposition as current CC evidence: the three prior red gates now have passing affected reruns. Their original failures and independent reproduction remain in the historical sections and raw receipts. This is still a CC proposal, not acceptance. All8 CA rows remain open for CDC's independent committed-candidate review; no seventh pass, historical waiver, release, or slice closure is inferred.

The reviewed three-file delta is committed as `b290ea312f937617546fe7ebab464de786a0dd37` (tree `953f50870d5a12eb45f5ba9827f962ccde4824cf`, parent `8a01b3d7ff9d6f3bc958975d07ba0e0e19bb5985`) with exactly the three authorized paths and the required consecutive parsed co-author trailers. The worktree is clean and index empty. The raw CC attempt record now contains83 entries with full captured fields; `validation.json` indexes the83 attempts and appends the iteration06 affected gate results. `execution.md` retains the full source/readback/attempt chronology. CDC now owns independent verification and final disposition; CC proposes no accepted row.
