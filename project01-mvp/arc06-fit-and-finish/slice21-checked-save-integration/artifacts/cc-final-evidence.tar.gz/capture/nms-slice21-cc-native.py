"""Metadata/control files only; terminals are exclusively native exec/write tools."""
import base64, datetime, hashlib, importlib.util, json, os, pathlib, sys, time, uuid
spec=importlib.util.spec_from_file_location('cap','/private/tmp/nms-slice21-cc-capture.py')
cap=importlib.util.module_from_spec(spec);spec.loader.exec_module(cap)
BASE=pathlib.Path('/private/tmp/nms-slice21-cc-native');BASE.mkdir(exist_ok=True)
def save(path,value):
    with path.open('x') as f:json.dump(value,f,indent=2);f.write('\n');f.flush();os.fsync(f.fileno())
def binaries():
    return {name:{'path':str(cap.SOURCE/name),'sha256':hashlib.sha256((cap.SOURCE/name).read_bytes()).hexdigest()} for name in ['target/debug/nms-copilot','target/debug/examples/repl_live_probe']}
def context():return {'utc':cap.utc(),'source':cap.metadata(),'inherited_env':{k:os.environ.get(k) for k in cap.ENV_KEYS},'binaries':binaries(),'support_scripts':{p:{'sha256':hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()} for p in [__file__,'/private/tmp/nms-slice21-cc-capture.py','/private/tmp/nms-slice21-cc-native-driver.js']}}
action=sys.argv[1]
if action=='prepare':
    row=int(sys.argv[2]);mode=sys.argv[3];watch=sys.argv[4];folder=BASE/uuid.uuid4().hex;folder.mkdir()
    manifest={'id':folder.name,'row':row,'mode':mode,'watch':watch,'dir':str(folder),'before_prepare':context()};save(folder/'before-prepare.json',manifest)
    prepare_argv=['target/debug/examples/repl_live_probe','prepare-unknown'] if row==10 else ['target/debug/examples/repl_live_probe','prepare',mode,watch]
    for label,argv in [('prepare',prepare_argv)]:
        if cap.capture(f'cc-native-{row}-{label}',argv):raise SystemExit(1)
    data=json.loads(cap.RECORD.read_text());raw=base64.b64decode(data['attempts'][-1]['raw_completion']['stdout']['base64']);fixture=json.loads(raw)
    verify='verify-unknown' if row==10 else 'verify-bind-failure'
    if cap.capture(f'cc-native-{row}-verify-initial',['target/debug/examples/repl_live_probe',verify,fixture['fixture']]):raise SystemExit(1)
    manifest.update(fixture);manifest['n']=0;manifest['ready_context']=context();save(folder/'case.json',manifest);print('CONTEXT='+json.dumps(manifest))
elif action=='register':
    request=pathlib.Path(sys.argv[2]);value=json.loads(request.read_text());folder=request.parent;ident=uuid.uuid4().hex
    record={'id':ident,'tool':value['tool'],'arguments':value['args'],'label':value['label'],'native_case':value['case'],'before':context()};save(folder/(ident+'-launch.json'),record)
    print(json.dumps({'id':ident,'dir':str(folder),'raw_path':str(folder/(ident+'-raw.json'))}))
elif action=='finish':
    folder=pathlib.Path(sys.argv[2]);ident=sys.argv[3];assert (folder/(ident+'-raw.json')).exists();save(folder/(ident+'-post.json'),context())
elif action in ['control','enqueue','marker']:
    fixture=pathlib.Path(sys.argv[2]);channel=sys.argv[5] if len(sys.argv)>5 else 'monitor'
    assert channel in ['monitor','restart']
    command=sys.argv[3];marker=sys.argv[4];out=fixture/('cc-'+channel+'.stdout');offset=out.stat().st_size if out.exists() else 0
    if action=='marker':offset=int(command)
    else:
        with (fixture/(channel+'.commands')).open('a') as f:f.write(command+'\n');f.flush();os.fsync(f.fileno())
    if action=='enqueue':print(json.dumps({'offset':offset,'channel':channel,'command':command}));raise SystemExit(0)
    deadline=time.monotonic()+10
    while time.monotonic()<deadline:
        body=out.read_text() if out.exists() else ''
        if marker in body[offset:]:print(body[offset:]);break
        err=(fixture/('cc-'+channel+'.stderr')).read_text() if (fixture/('cc-'+channel+'.stderr')).exists() else ''
        if err:raise RuntimeError('monitor stderr: '+err)
        time.sleep(.015)
    else:raise RuntimeError('missing fresh control marker '+marker)
elif action=='prepare-restart':
    fixture=sys.argv[2]
    if cap.capture('cc-native-10-prepare-restart',['target/debug/examples/repl_live_probe','prepare-restart',fixture]):raise SystemExit(1)
    data=json.loads(cap.RECORD.read_text());print(base64.b64decode(data['attempts'][-1]['raw_completion']['stdout']['base64']).decode(),end='')
elif action=='ready':
    fixture=pathlib.Path(sys.argv[2]);filename=sys.argv[3];deadline=time.monotonic()+10
    while time.monotonic()<deadline:
        p=fixture/filename
        if p.exists():print(p.read_text());break
        time.sleep(.015)
    else:raise RuntimeError('readiness missing '+filename)
elif action=='post':
    fixture=pathlib.Path(sys.argv[2]);cache=fixture/(fixture/'cache-path.txt').read_text().strip()
    def item(p):
        return {'exists':p.exists(),'is_file':p.is_file(),'is_dir':p.is_dir(),'bytes_hex':p.read_bytes().hex() if p.is_file() else None,'mtime_ns':p.stat().st_mtime_ns if p.exists() else None}
    print(json.dumps({'source':item(fixture/'save.json'),'cache':item(cache),'parent':item(cache.parent),'temp':item(cache.with_suffix('.rkyv.tmp')),'context':context()}))
else:raise RuntimeError('unknown action')
