#!/usr/bin/env python3
"""Run finite real `nms` children against a literal checked-name fixture."""
import base64
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile


def record(address, kind, vp, name=None):
    row = {
        "DD": {"UA": address, "DT": kind, "VP": vp},
        "DM": {},
        "OWS": {"LID": "", "UID": "owner", "USN": "Explorer", "PTK": "ST", "TS": 1700000000},
        "FL": {"U": 1},
    }
    if name is not None:
        row["DM"]["CN"] = name
    return row


def save_value():
    return {
        "Version": 4720,
        "Platform": "Mac|Final",
        "ActiveContext": "Main",
        "CommonStateData": {"SaveName": "Slice23CliNameSmoke", "TotalPlayTime": 100},
        "BaseContext": {
            "GameMode": 1,
            "PlayerStateData": {
                "UniverseAddress": {"RealityIndex": 0, "GalacticAddress": {
                    "VoxelX": 100, "VoxelY": 0, "VoxelZ": 0,
                    "SolarSystemIndex": 7, "PlanetIndex": 1,
                }},
                "PreviousUniverseAddress": {"RealityIndex": 9, "GalacticAddress": {
                    "VoxelX": 99, "VoxelY": 3, "VoxelZ": 4,
                    "SolarSystemIndex": 6, "PlanetIndex": 2,
                }},
                "Units": 7, "Nanites": 8, "Specials": 9,
                "PersistentPlayerBases": [{
                    "BaseVersion": 8, "GalacticAddress": "0x10070000000064",
                    "Position": [1.0, 2.0, 3.0], "Forward": [1.0, 0.0, 0.0],
                    "LastUpdateTimestamp": 1700000000, "Objects": [], "RID": "",
                    "Owner": {"LID": "", "UID": "AnchorUID", "USN": "Anchor", "PTK": "ST", "TS": 0},
                    "Name": "Anchor", "BaseType": {"PersistentBaseTypes": "HomePlanetBase"},
                    "LastEditedById": "", "LastEditedByUsername": "",
                }],
            },
        },
        "ExpeditionContext": {"GameMode": 6, "PlayerStateData": {
            "UniverseAddress": {"RealityIndex": 0, "GalacticAddress": {
                "VoxelX": 0, "VoxelY": 0, "VoxelZ": 0,
                "SolarSystemIndex": 0, "PlanetIndex": 0,
            }},
            "Units": 0, "Nanites": 0, "Specials": 0, "PersistentPlayerBases": [],
        }},
        "DiscoveryManagerData": {"DiscoveryData-v1": {"ReserveStore": 0, "ReserveManaged": 0, "Store": {"Record": [
            record("0x00070000000064", "SolarSystem", [], "Current Recovered"),
            record("0x10070000000064", "Planet", ["0xAB", 65537], "Recovered Moon"),
            record("0x00080000000065", "SolarSystem", [], "Kepler, \"α\"\nNorth"),
            record("0x20080000000065", "Planet", ["0xAC", 0], " Lush, \"β\"\nMoon "),
            record("0x00070900000064", "SolarSystem", [], "Named Only"),
            record("0x10070900000064", "Planet", ["0xAD", 4]),
            record("0x00090000000066", "SolarSystem", [], "Named Only"),
            record("0x30090000000066", "Planet", ["0xAE", 4]),
        ]}}},
    }


def run(binary, fixture, env, receipts, label, args, required, forbidden=(), timeout=20):
    argv = [str(binary), *args, "--save", str(fixture)]
    # Clap takes --save on the subcommand; move it before any nested show target.
    if args[0] == "show":
        argv = [str(binary), "show", "--save", str(fixture), *args[1:]]
    receipt_path = receipts / f"{label}.json"
    prelaunch = {
        "label": label,
        "argv": argv,
        "cwd": os.getcwd(),
        "started_utc": datetime.now(timezone.utc).isoformat(),
        "binary": str(binary),
        "binary_sha256": hashlib.sha256(binary.read_bytes()).hexdigest(),
        "fixture": str(fixture),
        "fixture_sha256_before": hashlib.sha256(fixture.read_bytes()).hexdigest(),
        "home": env.get("HOME"),
        "environment": {key: env.get(key) for key in ("NO_COLOR", "TERM")},
        "timeout_seconds": timeout,
    }
    prelaunch_path = receipts / f"{label}.prelaunch.json"
    prelaunch_path.write_text(json.dumps(prelaunch, separators=(",", ":")))
    raw_completion_path = receipts / f"{label}.raw-completion.json"
    try:
        result = subprocess.run(
            argv,
            env=env,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            check=False,
            timeout=timeout,
        )
        raw_completion = {
            **prelaunch,
            "exit": result.returncode,
            "stdout_b64": base64.b64encode(result.stdout).decode("ascii"),
            "stderr_b64": base64.b64encode(result.stderr).decode("ascii"),
            "ended_utc": datetime.now(timezone.utc).isoformat(),
        }
        raw_completion_path.write_text(
            json.dumps(raw_completion, separators=(",", ":"))
        )
        completion = {
            **raw_completion,
            "fixture_sha256_after": hashlib.sha256(fixture.read_bytes()).hexdigest(),
        }
    except subprocess.TimeoutExpired as error:
        raw_completion = {
            **prelaunch,
            "timed_out": True,
            "timeout_output_stdout_b64": base64.b64encode(error.stdout or b"").decode("ascii"),
            "timeout_output_stderr_b64": base64.b64encode(error.stderr or b"").decode("ascii"),
            "ended_utc": datetime.now(timezone.utc).isoformat(),
        }
        raw_completion_path.write_text(
            json.dumps(raw_completion, separators=(",", ":"))
        )
        completion = {
            **raw_completion,
            "fixture_sha256_after": hashlib.sha256(fixture.read_bytes()).hexdigest(),
        }
        receipt_path.write_text(json.dumps(completion, separators=(",", ":")))
        raise RuntimeError(f"child timed out; raw receipt retained at {receipt_path}") from error
    receipt_path.write_text(json.dumps(completion, separators=(",", ":")))
    stdout = result.stdout.decode("utf-8", errors="replace")
    stderr = result.stderr.decode("utf-8", errors="replace")
    if result.returncode != 0:
        raise RuntimeError(f"child failed rc={result.returncode}: {argv!r}; stderr={stderr!r}; raw receipt={receipt_path}")
    for needle in required:
        if needle not in stdout:
            raise RuntimeError(f"child output lacks {needle!r}: {stdout!r}")
    for needle in forbidden:
        if needle in stdout:
            raise RuntimeError(f"child output unexpectedly contains {needle!r}: {stdout!r}")
    return {
        "receipt": str(receipt_path),
        "argv": argv,
        "exit": result.returncode,
        "stdout_b64": completion["stdout_b64"],
        "stderr_b64": completion["stderr_b64"],
    }


def main():
    binary = Path(sys.argv[1]).resolve()
    if not binary.is_file():
        raise SystemExit(f"nms binary not found: {binary}")
    content = json.dumps(save_value(), ensure_ascii=False, separators=(",", ":")).encode("utf-8")
    directory = Path(tempfile.mkdtemp(prefix="slice23-cli-names-"))
    fixture = directory / "save.json"
    receipts = directory / "receipts"
    receipts.mkdir()
    home = directory / "home"
    home.mkdir()
    fixture.write_bytes(content)
    env = os.environ.copy()
    env.update({"NO_COLOR": "1", "TERM": "dumb", "HOME": str(home)})
    common = ["--from", "Anchor"]
    unfiltered = run(
        binary, fixture, env, receipts, "find-unfiltered",
        ["find", *common], ["Named Only", "Frozen", "-"],
    )
    named = run(
        binary, fixture, env, receipts, "find-named",
        ["find", "--named", *common],
        ["Current Recovered", "Recovered Moon", "Kepler", "Lush"],
        ["Named Only"],
    )
    show_named = run(
        binary, fixture, env, receipts, "show-named",
        ["show", "system", "Current Recovered"], ["Current Recovered", "Recovered Moon"],
    )
    show_unnamed_planet = run(
        binary, fixture, env, receipts, "show-unnamed-system",
        ["show", "system", "Named Only"],
        ["Named Only", "Frozen", "-"],
    )
    print(json.dumps({
        "binary": str(binary),
        "binary_sha256": hashlib.sha256(binary.read_bytes()).hexdigest(),
        "fixture": str(fixture),
        "fixture_sha256": hashlib.sha256(content).hexdigest(),
        "find_unfiltered_includes_unnamed_planet": unfiltered,
        "find_named_excludes_unnamed_planet": named,
        "show_named_system": show_named,
        "show_system_with_unnamed_planet": show_unnamed_planet,
    }, ensure_ascii=False, separators=(",", ":")))


if __name__ == "__main__":
    main()
